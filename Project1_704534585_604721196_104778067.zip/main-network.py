from network_q1 import *
from network_q2 import *
from network_q2b import *
from network_q2c import *
from network_q3 import *

#part 1
#plot_size_versus_day()
#part 2a
#linear_regression_model()
#part 2b
random_forest_model()
#part 2c
#neural_network_regression_model()
#part 3
#piecewise_linear_regression_analysis()
