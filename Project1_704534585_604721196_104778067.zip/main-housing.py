from housing_q4 import *

#part 4a
#linear_regression_model()
#part 4b
poly_regression_model()
