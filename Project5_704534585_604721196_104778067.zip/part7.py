from sklearn.decomposition import TruncatedSVD
from sklearn.multiclass import OneVsRestClassifier
from sklearn.model_selection import train_test_split
from sklearn.feature_extraction import text
from sklearn import svm
from sklearn import metrics
from common import *
import numpy as np
import json
import util, util_2

hashtag = '#nfl'
fname = retreive_filename_by_hashtag(hashtag)

data = []
target = []
author_list = {} 	# maps author to their index in data

##########################
## Reading Twitter Data ##
##########################

out = util.get_linecount(fname)
util.tic('Loading tweets w/ %s' % hashtag)

count = 0
for line in open(fname, 'r'):
	tweet = json.loads(line)
	author = tweet['author']['nick']
	original_author = tweet['original_author']['nick']
	
	# only process if the twitter is original (not retweet)
	if author == original_author:
		tweet_content = tweet['title']
		followers = tweet['author']['followers']
		popularity = 1
		if followers > 0:
			# log of base 5
			popularity = int(np.log(followers) / np.log(5))

		# cluster by author to reduce the dimension of TFxIDF
		if author not in author_list:
			author_list[author] = len(data)
			data.append(tweet_content)
			target.append(popularity)
		else:
			author_idx = author_list[author]
			data[author_idx] += tweet_content
			# popularity could vary by 1 or 2 for a user within the time
			# range, especially when the user doesn't have many followers,
			# we just take the user's peak popularity
			target[author_idx] = max(popularity, target[author_idx])

	count += 1
	# print progress to the screen...
	if count % 1000 == 0 or count == out:
		print '%d out of %s line(s) finished' % (count, out)

util.toc()

#####################
## Text Processing ##
#####################

data_train, data_test, target_train, target_test = train_test_split(data,
	target, train_size=0.6, random_state=33)

util.tic('Vectorizing...')

count_vect = text.CountVectorizer(min_df=1, stop_words='english',
	analyzer = 'word', tokenizer=util_2.my_tokenizer)
tfidf_transformer = text.TfidfTransformer()
svd = TruncatedSVD(n_components=50, algorithm='arpack')

X_train_counts = count_vect.fit_transform(data_train)
X_train_tfidf = tfidf_transformer.fit_transform(X_train_counts)
X_train_svd = svd.fit_transform(X_train_tfidf)

X_test_counts = count_vect.transform(data_test)
X_test_tfidf = tfidf_transformer.transform(X_test_counts)
X_test_svd = svd.transform(X_test_tfidf)

util.toc()

util.tic('Building multi-class classifier...')

clf = OneVsRestClassifier(svm.LinearSVC(random_state=42))
clf.fit(X_train_svd, target_train)

util.toc()

y_pred = clf.predict(X_test_svd)
y_true = target_test

print "Classification report and confusion matrix:"
print metrics.classification_report(y_true, y_pred)
print metrics.confusion_matrix(y_true, y_pred)
